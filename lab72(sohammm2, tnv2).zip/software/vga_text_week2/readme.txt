This template is starting point for creating a project based on your custom C code.
It will provide you a default project to which you can add your software files. To
add files to a project, manually copy the file into the application directory (e.g. 
using Windows Explorer), then right click on your application project and select 
refresh.

You can also add files to the project using the Nios II Software Build Tools for Eclipse import function. 
Select File -> Import. 
Expand General and select File System in the Import Window and click Next.
Identify the appropriate source and destination directories.
Check the files you want to add and click Finish.
